package com.drivesoft.demo.controller;

import com.drivesoft.demo.dto.PopulateDataRequest;
import com.drivesoft.demo.service.AccountService;
import com.drivesoft.demo.dto.ResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/accounts")
public class AccountController {
    @Autowired
    AccountService accountService;


    @PostMapping(value = "/populateData")
    public ResponseBody populateData(@RequestBody PopulateDataRequest populateDataRequest) {
        return accountService.populateData(populateDataRequest);
    }

    @GetMapping(value = "/fetchpopulatedData")
    public ResponseBody fetchpopulatedData() {
        return accountService.fetchPopulatedData();
    }
}
