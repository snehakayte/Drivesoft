package com.drivesoft.demo.controller;

import com.drivesoft.demo.dto.ResponseBody;
import com.drivesoft.demo.security.AuthenticationService;
import com.drivesoft.demo.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;


@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private JwtUtil jwtUtil;


    @PostMapping()
    public ResponseBody<?> createToken(
            @RequestParam String username,
            @RequestParam String password) {
        if (authenticationService.authenticate(username, password)) {
            String token = jwtUtil.generateToken(username);
            return new ResponseBody<>(HttpStatus.OK, "Token fetched successfully", token);
        } else {
            return new ResponseBody<>(HttpStatus.UNAUTHORIZED, "Invalid credentials", null);

        }
    }
}

