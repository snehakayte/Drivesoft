package com.drivesoft.demo.dao;

import com.drivesoft.demo.entity.Account;

import java.util.List;

public interface AccountDao {

    List<Integer> fetchAccountIds();

    List<Account> findAll();

}
