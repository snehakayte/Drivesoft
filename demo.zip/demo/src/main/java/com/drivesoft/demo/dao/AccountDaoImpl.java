package com.drivesoft.demo.dao;

import com.drivesoft.demo.entity.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.List;

@Repository
public class AccountDaoImpl implements AccountDao {
    @PersistenceContext
    EntityManager em;

    public List<Integer> fetchAccountIds() {
        TypedQuery<Integer> query = em.createQuery("SELECT s.acctID FROM Account s ", Integer.class);
        return query.getResultList();
    }


    public List<Account> findAll() {
        TypedQuery<Account> query1 = em.createQuery("Select a from Account a ", Account.class);
        List<Account> customersList = query1.getResultList();
        return customersList;
    }
}
