package com.drivesoft.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountListResponse {
    @JsonProperty("Status")
    String Status;
    @JsonProperty("Message")
    String Message;
    @JsonProperty("TotalRecords")
    String TotalRecords;
    @JsonProperty("TotalPages")
    String TotalPages;
    @JsonProperty("PageNumber")
    String PageNumber;
    @JsonProperty("BeginningPage")
    String BeginningPage;
    @JsonProperty("EndingPage")
    String EndingPage;
    @JsonProperty("Data")
    List<Record> Data;
}
