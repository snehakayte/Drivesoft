package com.drivesoft.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountResponse {
    private String contractSalesPrice;
    private String acctType;
    private String salesGroupPerson1ID;
    private String contractDate;
    private String collateralStockNumber;
    private String collateralYearModel;
    private String collateralMake;
    private String collateralModel;
    private String borrower1FirstName;
    private String borrower1LastName;
    private String acctID;


}

