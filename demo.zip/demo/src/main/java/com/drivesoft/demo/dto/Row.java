package com.drivesoft.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Row {


    @JsonProperty("AcctType")
    String acctType;
    @JsonProperty("SalesGroupPerson1ID")
    String salesGroupPerson1ID;

    @JsonProperty("ContractDate")
    String contractDate;
    @JsonProperty("CollateralStockNumber")
    String collateralStockNumber;
    @JsonProperty("CollateralYearModel")
    String collateralYearModel;
    @JsonProperty("CollateralMake")
    String collateralMake;
    @JsonProperty("CollateralModel")
    String collateralModel;
    @JsonProperty("Borrower1FirstName")
    String borrower1FirstName;
    @JsonProperty("Borrower1LastName")
    String borrower1LastName;
    @JsonProperty("AcctID")
    String acctID;
}
