package com.drivesoft.demo.entity;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "Account")
@Data
public class Account {
    @Id
    @Column(name = "acct_id")
    private Integer acctID;

    @Column(name = "acct_type")
    private String acctType;
    @Column(name = "sales_group_person1_id")
    private Integer salesGroupPerson1ID;

    @Column(name = "contract_date")
    private Timestamp contractDate;
    @Column(name = "collateral_stock_number")
    private String collateralStockNumber;
    @Column(name = "collateral_year_model")
    private Integer collateralYearModel;
    @Column(name = "collateral_make")
    private String collateralMake;
    @Column(name = "collateral_model")
    private String collateralModel;
    @Column(name = "borrower1_first_name")
    private String borrower1FirstName;
    @Column(name = "borrower1_last_name")
    private String borrower1LastName;
}
