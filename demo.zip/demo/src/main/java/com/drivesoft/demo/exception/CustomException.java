package com.drivesoft.demo.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@AllArgsConstructor
public class CustomException extends RuntimeException {
    private String message;
    private String details;

}
