
package com.drivesoft.demo.mapper;

import com.drivesoft.demo.dto.Row;
import com.drivesoft.demo.entity.Account;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ReportingPolicy;

@Mapper(
        componentModel = MappingConstants.ComponentModel.SPRING,
        unmappedTargetPolicy = ReportingPolicy.IGNORE
)
public interface ObjectMapper {

    @Mapping(target = "contractDate", ignore = true)
    Account rowToAccount(Row row);
}

