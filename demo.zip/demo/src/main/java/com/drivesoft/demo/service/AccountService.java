package com.drivesoft.demo.service;

import com.drivesoft.demo.dto.PopulateDataRequest;
import com.drivesoft.demo.dto.ResponseBody;


public interface AccountService {

    public ResponseBody populateData(PopulateDataRequest populateDataRequest);

    public ResponseBody fetchPopulatedData();

}
