package com.drivesoft.demo.service;

import com.drivesoft.demo.dao.AccountDao;
import com.drivesoft.demo.dao.AccountRepository;
import com.drivesoft.demo.entity.Account;
import com.drivesoft.demo.dto.PopulateDataRequest;
import com.drivesoft.demo.dto.ResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountServiceImpl implements AccountService {
    @Autowired
    private IDMSService idmsService;
    @Autowired
    private AccountDao accountDao;
    @Autowired
    private AccountRepository accountRepository;

    public ResponseBody populateData(PopulateDataRequest populateDataRequest) {
        String authToken = idmsService.getAuthToken();
        List<Account> accounts = idmsService.getAccounts(authToken, populateDataRequest);
        List<Integer> accountIdsPresentInDB = accountDao.fetchAccountIds();
        accounts = accounts.stream().filter(accountResponse -> !accountIdsPresentInDB.contains(accountResponse.getAcctID())).collect(Collectors.toList());
        accountRepository.saveAll(accounts);
        return new ResponseBody(HttpStatus.OK, "Data populated successfully.", null);
    }

    public ResponseBody fetchPopulatedData() {
        return new ResponseBody(HttpStatus.OK, "Data fetched successfully.", accountDao.findAll());
    }

}
