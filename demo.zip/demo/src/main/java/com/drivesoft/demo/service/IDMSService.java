package com.drivesoft.demo.service;

import com.drivesoft.demo.dto.AccountListResponse;
import com.drivesoft.demo.dto.PopulateDataRequest;
import com.drivesoft.demo.dto.Row;
import com.drivesoft.demo.dto.TokenResponseBody;
import com.drivesoft.demo.entity.Account;
import com.drivesoft.demo.exception.CustomException;
import com.drivesoft.demo.mapper.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class IDMSService {

    @Autowired
    ObjectMapper objectMapper;
    private static final String BASE_URL = "https://idms.dealersocket.com";
    private static final String AUTH_URL = "/api/authenticate/GetUserAuthorizationToken";
    private static final String ACCOUNTS_URL = "/api/account/GetAccountList";
    private static final String USERNAME = "testerAPI@drivesoft.tech";
    private static final String PASSWORD = "HelloVIaCST3st@@Main";
    WebClient webClient = WebClient.create(BASE_URL);

    public String getAuthToken() {

        try {
            TokenResponseBody response = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(AUTH_URL)
                            .queryParam("username", USERNAME)
                            .queryParam("password", PASSWORD)
                            .queryParam("InstitutionID", "107007")
                            .build())
                    .retrieve()
                    .bodyToMono(TokenResponseBody.class).block();
            return response.getToken();
        } catch (Exception e) {
            throw new CustomException("Error fetching authentication token: " + e.getMessage(), "");
        }
    }

    public List<Account> getAccounts(String authToken, PopulateDataRequest populateDataRequest) {
        try {
            AccountListResponse accounts = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(ACCOUNTS_URL)
                            .queryParam("Token", authToken)
                            .queryParam("LayoutID", populateDataRequest.getLayoutID())
                            .queryParam("AccountStatus", populateDataRequest.getAccountStatus())
                            .queryParam("InstitutionID", populateDataRequest.getInstitutionID())
                            .queryParam("PageNumber", populateDataRequest.getPageNumber())
                            .build())
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(AccountListResponse.class).block();

            List<Row> rows = accounts.getData().stream().map(record -> record.getRow()).collect(Collectors.toList());
            List<Account> accountList = new ArrayList<>();
            rows.stream().forEach(row -> {
                accountList.add(objectMapper.rowToAccount(row));
            });
            return accountList;
        } catch (Exception e) {
            throw new CustomException("Error fetching authentication token: " + e.getMessage(), "");
        }
    }
}
