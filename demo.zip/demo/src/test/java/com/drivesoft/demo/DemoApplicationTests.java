package com.drivesoft.demo;


import org.junit.Ignore;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

    @Ignore
    void contextLoads() {
    }

}
